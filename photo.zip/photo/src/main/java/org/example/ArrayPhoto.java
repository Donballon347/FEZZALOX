package org.example;
import java.util.ArrayList;

public class ArrayPhoto {
    private ArrayList<Photo> arrayPhotos;
    public ArrayPhoto () {
        arrayPhotos = new ArrayList<Photo>();
    }
    public void addItem(Photo item){
        arrayPhotos.add(item);
    }

    public void removeItem(Photo item){
        arrayPhotos.remove(item);
    }
   // Создать метод, который будет искать объект по серийному номеру и удалять весь объект ?????? принимать параметр (айдишник) переменную из Photo, перебирать массив и получать индекс элемента и его удалать
//    public void removeItem(long serial_number_of_the_device){
//        for (int i = 0; i < arrayPhotos.size(); i++){
//            int index = arrayPhotos.indexOf(serial_number_of_the_device);
//
//        }
//        arrayPhotos.remove();
//    }
   public void removeItem(String serial_number_of_the_device, ArrayList<Photo> arrayPhotos) {
       for(int i = 0; i < arrayPhotos.size(); i++) {
           for (int j = 0; j < 6; j++){
               if(arrayPhotos.contains(serial_number_of_the_device)) {
                   arrayPhotos.remove(i);
               }
           }
       }
   }
    public boolean hasArrayPhotos() {
        return !arrayPhotos.isEmpty();
    }
    public ArrayList<Photo> retriveArrayPhotos() {
        ArrayList<Photo> result = new ArrayList<Photo>();
        arrayPhotos.clear();
        return result;
    }

    // Getter
    public ArrayList<Photo> getArrayPhotos() {
        return new ArrayList<>(arrayPhotos);
    }
    // Setter
    public void setArrayPhotos(ArrayList<Photo> arrayPhotos) {
        this.arrayPhotos = new ArrayList<>(arrayPhotos);
    }

    // Сеттер, который будет устанавливать значение массива (по серийному номеру)
    public void setArrayPhotos(String serial_number_of_the_device, ArrayList<Photo> arrayPhotos) {
        for(int i = 0; i < arrayPhotos.size(); i++) {
            for (int j = 0; j < 6; j++) {
                if (arrayPhotos.contains(serial_number_of_the_device)) {
                    this.arrayPhotos = new ArrayList<>(arrayPhotos);
                }
            }
        }
    }
    // Геттер, который будет выдавать массив (по серийному номеру)
    public ArrayList<Photo> getArrayPhotos(Photo serial_number_of_the_device) {
        for(int i = 0; i < arrayPhotos.size(); i++) {
            if(arrayPhotos.contains(serial_number_of_the_device)) {
                return new ArrayList<>(arrayPhotos);
            }
        }
        return arrayPhotos;
    }
}
