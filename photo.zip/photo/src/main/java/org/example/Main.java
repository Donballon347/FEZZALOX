package org.example;

import java.util.ArrayList;

public class Main {
    public static void main(String[] args)
    {
        Photo photo = new Photo(114159265359L, 18, new StringBuilder("Optic"), 2.5f, "English",347);
        Photo photo2 = new Photo(235159265359L, 23, new StringBuilder("O23423tic"), 23.5f, "Engl233423ish",31247);
        Photo photo3 = new Photo(34159265359L, 23, new StringBuilder("O23423tic"), 23.5f, "Engl233423ish",31247);

//        System.out.println("Serial number of the device: " + photo.getSerial_number_of_the_device());
//        System.out.println("Matrix resolution: " + photo.getMatrix_resolution());
//        System.out.println("Type of viewfinder: " + photo.getType_of_viewfinder());
//        System.out.println("Optical zoom: " + photo.getOptical_zoom());
//        System.out.println("Menu language: " + photo.getMenu_language());
//        System.out.println("Flash range: " + photo.getFlash_range());

        photo.setSerial_number_of_the_device(43_534_543L);
        photo.setMatrix_resolution(18);
        photo.setType_of_viewfinder(new StringBuilder("Optic"));
        photo.setOptical_zoom(2.5f);
        photo.setMenu_language("Eng");
        photo.setFlash_range(347);

        //Photo item = photo;
        ArrayPhoto arrayPhoto = new ArrayPhoto();

        ArrayList<Photo> arrayPhotos = new ArrayList<Photo>();
        ArrayList<Photo> arrayPhotos2 = new ArrayList<Photo>();

        arrayPhotos.add(photo);
        arrayPhoto.setArrayPhotos(arrayPhotos);

        // Удалён
        arrayPhoto.addItem(photo2);
        Photo item = photo2;
        arrayPhoto.removeItem(item);

        arrayPhotos.add(photo3);
        arrayPhoto.setArrayPhotos(arrayPhotos);

        arrayPhoto.setArrayPhotos("34159265359L", arrayPhotos2);
        //arrayPhoto.removeItem("228159265359L", arrayPhotos2);

        System.out.println(arrayPhoto.getArrayPhotos());
        //System.out.println(arrayPhoto.hasArrayPhotos());


        System.out.println("\n2:");
        arrayPhotos2.add(photo);
        arrayPhoto.setArrayPhotos(arrayPhotos2);
        System.out.println(arrayPhoto.getArrayPhotos());
        System.out.println(arrayPhotos.size());
    }
}