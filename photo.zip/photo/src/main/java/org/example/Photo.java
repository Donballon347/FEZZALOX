package org.example;

public class Photo {
    private long serial_number_of_the_device;
    private int matrix_resolution;
    private StringBuilder type_of_viewfinder;
    private float optical_zoom;
    private String menu_language;
    private int  flash_range;

    // конструктор по умолчанию
    public Photo() {
        serial_number_of_the_device = 314159265359L;
        matrix_resolution = 18;
        type_of_viewfinder = new StringBuilder("Optic");
        optical_zoom = 2.5f;
        menu_language = "English";
        flash_range = 347;
    }
    public Photo(long newSerial_number_of_the_device, int newMatrix_resolution, StringBuilder newType_of_viewfinder, float newOptical_zoom, String newMenu_language, int  newFlash_range) {
        serial_number_of_the_device = newSerial_number_of_the_device;
        matrix_resolution = newMatrix_resolution;
        type_of_viewfinder = newType_of_viewfinder;
        optical_zoom = newOptical_zoom;
        menu_language = newMenu_language;
        flash_range = newFlash_range;
    }
    // Serial_number_of_the_device
    public long getSerial_number_of_the_device() { return serial_number_of_the_device; }
    public void setSerial_number_of_the_device(long serial_number_of_the_device) { this.serial_number_of_the_device = serial_number_of_the_device; }

    // Matrix_resolution
    public int getMatrix_resolution() { return matrix_resolution; }
    public void setMatrix_resolution(int matrix_resolution) { this.matrix_resolution = matrix_resolution; }

    // Type_of_viewfinder
    public StringBuilder getType_of_viewfinder() { return type_of_viewfinder; }
    public void setType_of_viewfinder(StringBuilder type_of_viewfinder) { this.type_of_viewfinder = type_of_viewfinder; }

    // Optical_zoom
    public float getOptical_zoom() { return optical_zoom; }
    public void setOptical_zoom(float optical_zoom) { this.optical_zoom = optical_zoom; }

    // Menu_language
    public String getMenu_language() { return menu_language; }
    public void setMenu_language(String menu_language) { this.menu_language = menu_language; }

    // Flash_range
    public int getFlash_range() { return flash_range; }
    public void setFlash_range(int flash_range) { this.flash_range = flash_range; }

    @Override
    public String toString() {
        return "Photos :" + '\n' +
                "serial_number_of_the_device: " + serial_number_of_the_device + '\n' +
                "matrix_resolution: " + matrix_resolution + '\n' +
                "type_of_viewfinder: " + type_of_viewfinder + '\n' +
                "optical_zoom: " + optical_zoom + '\n' +
                "menu_language: " + menu_language + '\n' +
                "flash_range: " + flash_range + '\n';
    }
}
