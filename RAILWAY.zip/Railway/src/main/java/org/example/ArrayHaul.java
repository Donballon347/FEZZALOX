package org.example;
import java.util.ArrayList;


public class ArrayHaul {
    private ArrayList<Haul> arrayHauls;
    public ArrayHaul () {
        arrayHauls = new ArrayList<Haul>();
    }

    FEZZA ЛОХ ОБЕЛСЯ БЛОХ СЕЛ НА ЛАВОЧКУ И СДОХ, А ПОД ЛАВОЧКОЙ ЗМЕЯ ОТКУСИЛА ПОЛ Х*Я
}